#dette programet skal skrive navn + etternavn og alderen.
#Variabel 1 = navn (ditt navn) i dette tilfelet Mats
navn="Mats"
#Neste variabel = etternavn som er Vik Pettersen i dette tilfelet
 
etternavn=" Vik Pettersen"
#Neste variabelen = alder som er hvor gammel jeg er i dette tilfellet

alder=20
#Her ber jeg programet skrive ut en setning som inkludere navn, etternavn og alder ved å bruke f-string for å formatere setningen

print(f'Hei. Jeg heter {navn + etternavn} og er {alder} år gammel')