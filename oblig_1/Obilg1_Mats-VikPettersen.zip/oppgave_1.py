#Dette programet skriver ut hello world
print("Hello World")