from car_dealership import Car

def print_car_information(car):
    car.print_car_information()

# Test
car1 = Car("Toyota", "Corolla", 96000, 2012, 8, False, 163000)
print_car_information(car1)

