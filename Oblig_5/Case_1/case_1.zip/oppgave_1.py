from webshop import print_ware_information

# Eksempeldata for vare
ware = {
    "name": "Example Ware",
    "price": 3999,
    "number_in_stock": 30,
    "description": "A non-existent ware used only for this example."
}

# Kall funksjonen for å skrive ut informasjon
print_ware_information(ware)

