def print_list(list_to_print):
    for element in list_to_print:
        print(element)


favoritt_mat = ["Pizza", "Taco", "Burger"]
print_list(favoritt_mat)