import random
def tall():
    tilfeldig_tall = random.randrange(0,100)
    
    print("*********")
    print(f"***{tilfeldig_tall}***") 
    print("*********")

tall()
tall()
tall()